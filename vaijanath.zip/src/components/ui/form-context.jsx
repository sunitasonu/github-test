import { createContext } from "react";

export const FormFieldContext = createContext(null);
export const FormItemContext = createContext(null);
