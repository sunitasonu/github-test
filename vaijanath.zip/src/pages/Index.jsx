
import React from 'react';
import DashboardContent from '@/components/DashboardContent';

const Index = () => {
  return <DashboardContent />;
};

export default Index;
